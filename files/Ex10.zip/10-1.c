#include <stdio.h>

#define MIN(a,b) ((a)<(b)?(a):(b))

main ()
{
	int N;
	int i, j;
	int d1, d2;

	scanf ("%d", &N);

	for (i = 0; i < N * 2 - 1; i++) {
		for (j = 0; j < N * 2 - 1; j++) {
			d1 = (i >= N) ? 2 * N - i - 2: i;
			d2 = (j >= N) ? 2 * N - j - 2: j;
			printf("%d", MIN(d1, d2) + 1);
		}
		printf ("\n");
	}
}