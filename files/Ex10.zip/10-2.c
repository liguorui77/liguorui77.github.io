#include <stdio.h>

int sums(int num)
{
	int sum;
	sum = 0;
	while (num != 0)
	{
		sum += num % 10;
		num /= 10;
	}
	return sum;
}

int main()
{
	int number;
	scanf("%d", &number);
	printf("%d", sums(number));
	return 0;
}