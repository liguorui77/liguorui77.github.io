#include <stdio.h>

int main()
{
	float number;
	scanf("%f", &number);
	if (number - (int)number >= 0.5)
		printf("%d", (int)(number+1));
	else
		printf("%d", (int)number);
	return 0;
}
