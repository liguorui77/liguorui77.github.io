int Count_Digit ( const int N )
{
  int n=N, sum=0, tmp;
  if(n<0)  n=-n;
  while(n>0)
  {
    tmp=n%10;
    n=n/10;
    if(tmp%2==0)
       sum+=tmp;
  } 
  return sum;
}