Employee::Employee(string  n,int  ag)
{
  name=n;
  age=ag;
}

void Employee::GetInformation()
{
  cout<<"name:"<<name<<",age:"<<age<<endl;
}