#include <stdio.h>

int number;

int main()
{
	int i, j, pos;

	scanf ("%d", &number);

	pos = number / 2 + 1;
	for (i = 0; i < pos; i++)
	{
		for (j = 0; j < pos - 1 - i; j++)
			printf (" ");
		for (j = 0; j < 2*i+1; j++)
			printf ("*");
		printf ("\n");
	}

	return 0;
}