#include <iostream> 
using namespace std;

int main()
{
    int a,b,c,d,temp;
    cin>>a>>b;

  
    temp=a;
    c=0;
    while(temp>0)
    {
        c=c*10+temp%10;
        temp/=10;
    }

    temp=b;
    d=0;
    while(temp>0)
    {
        d=d*10+temp%10;
        temp/=10;
    }

    if(a*b==c*d)
    	cout<<a<<"*"<<b<<"="<<c<<"*"<<d;
    else
    	cout<<a<<"*"<<b<<"!="<<c<<"*"<<d;

     return 0;
}