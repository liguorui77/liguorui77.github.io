#include <iostream>
#include <cmath>
using namespace std;

int main()
{
	int n,sum=0,t,jc,m,p;
	cin>>n;
	cout<<n<<",";
	
	m=n;	
	
	int digits=0;
	while(n!=0)
	{
		n/=10;
		digits++;
	}
	
	n=m;
	

	while(digits>0)
	{
		p=(int)pow(10.0,digits-1);
		t=n/p;
		n%=p;
		jc=1;
		for(int i=1;i<=t;i++)
			jc*=i;
		cout<<t<<"!";
		cout<<(digits>1?"+":"=");
		sum+=jc;
		digits--;
	}
	cout<<sum<<endl;
	if(sum==m) 
		cout<<"Yes"<<endl;
	else 
		cout<<"No"<<endl;
}
