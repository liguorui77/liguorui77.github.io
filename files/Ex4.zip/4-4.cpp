#include <iostream> 
using namespace std;

bool loop(int x)
{
	int r;
	int s = 0;
	int n = x;

	do {
		r = x % 10;
		s = s * 10 + r;
	} while((x = x / 10)!=0);

	return (n == s);
}

bool even(int x)
{
	return(x%2==0);
}


int main()
{
	int a, b;
	int i;
	cin>>a>>b; 	
	for (i = a; i <= b; i++)
		if (loop(i) && even(i))
			cout<<i<<endl;
	return 0;
}