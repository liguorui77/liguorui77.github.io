#include <iostream> 
using namespace std;

int main()
{
	int a,b,i;
	cin>>a>>b;

	i=2;
	while(a>=i)
	{
		while( (a%i==0) && (b%i==0) )
		{
			a/=i;
			b/=i;
		}
		i++;
	}
	cout<<a<<" "<<b; 
	return 0;
}