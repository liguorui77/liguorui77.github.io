#include<stdio.h>

void selectSort(int arr[], int n)
{
	int i,j, k, temp; 
	for(i=0;i<n-1;i++)
	{
		k=i;
		for(j=i+1;j<n;j++)
			if(arr[j]>arr[k])
				k=j;	
		if(i!=k)
		{
			temp=arr[i];arr[i]=arr[k];arr[k]=temp;
		}						
	}
}

int main()
{
	int m,n,i;
	int a[100];
	scanf("%d",&m);
	for(i=0;i<m;i++)
	{
		scanf("%d",&a[i]);
	}
	scanf("%d",&n);
	for(i=m;i<m+n;i++)
	{
		scanf("%d",&a[i]);
	}
	selectSort(a,m+n);
	for(i=0;i<m+n;i++)
	{
	 
		if(a[i]!=a[i+1] || i==m+n-1)
		{
			printf("%d ",a[i]);		
		}
	}
}
