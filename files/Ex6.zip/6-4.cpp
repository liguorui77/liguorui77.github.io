#include <iostream>
using namespace std;

int main()
{
    int a[3][3];

    for(int i=0;i<3;i++)
        for(int j=0;j<3;j++)
            cin>>a[i][j];

    int flag, max, maxi, maxj;

    for(int i=0;i<3;i++)
    {
        max=a[i][0];
        maxi=i;
		maxj=0;
        
        for(int j=1;j<3;j++)
        {
            if(max < a[i][j])
            {
                max = a[i][j];
                maxi = i;
                maxj = j;
            }
        }

        flag = 1;
        for(int k=0;k<3;k++)
        {
            if(max>a[k][maxj])
            {
                flag = 0;
                break;
            }
        }

        if(flag == 1)
        {
            cout<<"Saddle point:"<<"a["<<maxi<<"]["<<maxj<<"]="<<max<<endl;
            break;
        }
    }

    if(flag == 0)
        cout<<"There is no saddle point"<<endl;

    return 0;
}
