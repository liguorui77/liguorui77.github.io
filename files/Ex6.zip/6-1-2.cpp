#include <iostream>
using namespace std;


int trans (char *s, int a[])
{
	int n = 0, d;
	while (*s != '\0')
	{
		while ((*s > '9' || *s < '0')&& (*s != '\0'))
			s++;
		if (*s == '\0')
			break;

		d = 0;
		while (*s >= '0' && *s <= '9')
		{
			d = 10 * d + (*s - '0');
			s++;
		}
		a[n] = d;
		n++;
	}
	return n;
}

int main()
{
	char s[100];
	cin>>s;
	int a[100], i, n;
	n = trans (s, a);
	cout<<n<<endl;
	for (i = 0; i < n; i++)
		 cout<<a[i]<<" ";
	cout<<endl;
	return 0;
}
