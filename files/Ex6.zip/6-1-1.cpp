#include <iostream>
using namespace std;
 
int main() {
    char str[81];
    cin.getline(str, 81);
    int len = strlen(str);
    int count = 0;
    int num[80];  
    int index = 0;
    for (int i = 0; i < len; ++i) {
        if (isdigit(str[i])) {
            int temp = 0;
            while (i < len && isdigit(str[i])) {
                temp = temp * 10 + (str[i] - '0');
                ++i;
            }
            num[count++] = temp;
        }
    }
    cout << count << endl;
    for (int i = 0; i < count; ++i) {
        cout << num[i];
        if (i < count - 1) {
            cout << " ";
        }
    }
    cout << endl;
    return 0;
}
