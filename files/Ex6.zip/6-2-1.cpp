#include <iostream>
using namespace std;

int main()
{
    int m=10,n=10;
	int a[m][n],b[n][m];
	
    cin>>m>>n;    


    for (int i=0;i<m;i++)
        for(int j=0;j<n;j++)
            cin>>a[i][j];
      
	for(int i = 0; i < m; i++)
			for(int j = 0; j < n; j++)
				b[j][m- i - 1] = a[i][j];  


    cout<<n<<" "<<m<<endl;
    for (int i=0;i<n;i++)
    {
		for(int j=0;j<m;j++)
            cout<<b[i][j]<<" ";
  		cout<<endl;
    }

    return 0;
}
