#include <iostream>
using namespace std;

int main()
{
    int m=10,n=10,max;
	int a[m][n],b[n][m];
	
    cin>>m>>n;    
    max=m>n?m:n;
    

    for (int i=0;i<m;i++)
        for(int j=0;j<n;j++)
            cin>>a[i][j];
            
    // rotate around diagonal 
    for (int i = 0; i < max; ++i) {
        for (int j = 0; j < i; ++j) {
            swap(a[i][j], a[j][i]);
        }
    }            

	// rotate horizontally 
    for (int i = 0; i < m / 2; ++i) {
        for (int j = 0; j < n; ++j) {
            swap(a[j][i], a[j][m - i - 1]);
        }
    }

    cout<<n<<" "<<m<<endl;
    for (int i=0;i<n;i++)
    {
		for(int j=0;j<m;j++)
            cout<<a[i][j]<<" ";
  		cout<<endl;
    }

    return 0;
}
