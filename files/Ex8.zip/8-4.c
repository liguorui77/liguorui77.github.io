#include "stdio.h"
#include "string.h" 

int strend(char s[],char t[])
{
	int i,j,l1,l2;
	l1=strlen(s);
	l2=strlen(t);
	if(l1<l2)
		return 0;
	for(i=l2-1,j=l1-1;i>=0;i--,j--)
		if(t[i]!=s[j])
			return 0;
	return 1;	
}

int main()
{
	char s[1000],t[1000];
	int rc;
	gets(s);
	gets(t);
	rc=strend(s,t);
	if(rc == 1)
		printf("Yes");
	else 
		printf("No");	
}