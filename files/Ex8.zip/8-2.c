#include<stdio.h>
void main(){
	int N,i,j,k;
	int a[10][10],sum=0;
	int b[10][10],c[10][10]={0};
	scanf("%d",&N);
	for(i=0;i<N;i++)
		for(j=0;j<N;j++)
			scanf("%d",&a[i][j]);

	for(i=0;i<N;i++)
		for(j=0;j<N;j++)
			scanf("%d",&b[i][j]);

	for(i=0;i<N;i++)
	{
		for(j=0;j<N;j++)
		{
			sum=0;
			for(k=0;k<N;k++){
				sum+=a[i][k]*b[k][j];
				
			}
			c[i][j]+=sum;
		}		
	}
	
	for(i=0;i<N;i++)
	{
		for(j=0;j<N;j++)
			printf("%10d",c[i][j]);
		printf("\n");
	}
}
