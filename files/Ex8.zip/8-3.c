#include <stdio.h>
int main()
{
	int i,j,ch,max,count[26]={0};

	while((ch=getchar())!=EOF)
		if(ch>='a'&&ch<='z')
			count[ch-'a']++;

	max=0;
	for(i=0;i<26;i++)
		if(count[i]>max)
			max=count[i];

	for(i=max;i>0;i--)
	{
		for(j=0;j<26;j++)
			if(count[j]>=i)
				printf("*");
			else
				printf(" ");
		printf("\n");
	}

	for(i=0;i<26;i++)
		printf("%c",i+'a');
	printf("\n");

	return 0;
}