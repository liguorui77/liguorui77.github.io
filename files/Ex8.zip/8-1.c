#include<stdio.h>
struct Date {
   int year;
   int month;
   int day;
};
int leap(int year) {
	if (year%4==0 && year%100!=0 || year%400==0)
		return 1;
	else
		return 0;
}
int findday(int year,int month,int day) {
	int days;
	days=day;
	switch(month-1) {
		case 12:days+=31;
		case 11:days+=30;
		case 10:days+=31;
		case  9:days+=30;
		case  8:days+=31;
		case  7:days+=31;
		case  6:days+=30;
		case  5:days+=31;
		case  4:days+=30;
		case  3:days+=31;
		case  2:if (leap(year)==1) days+=29;
			    else days+=28;
		case 1:days+=31;
	}
	return days;
}
int main() {
    struct Date date1,date2;
	int i,days;
	days=0;
	scanf("%d %d %d",&date1.year,&date1.month,&date1.day);
	scanf("%d %d %d",&date2.year,&date2.month,&date2.day);
	
	if (date1.year == date2.year) {
		days=findday(date2.year,date2.month,date2.day)
			-findday(date1.year,date1.month,date1.day);
	}
	else if (date1.year == date2.year -1) {
		days=365+leap(date1.year)-findday(date1.year,date1.month,date1.day)+
			findday(date2.year,date2.month,date2.day);
	}
	else {
		days=365*(date2.year-date1.year-1);
		for (i=date1.year+1;i<date2.year;i++)
			days+=leap(i);
		days+=365+leap(date1.year)-findday(date1.year,date1.month,date1.day)+
			findday(date2.year,date2.month,date2.day);
	}
	printf("%d",days);
	return 0;
}
