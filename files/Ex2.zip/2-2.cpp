#include <iostream> 
using namespace std;
int main()
{
	long a;
	cin>>a;;
	cout<<oct<<a<<endl;
	return 0;
}