#include <iostream> 
#include <iomanip>
using namespace std;
int main()
{
	long f;
	cin>>f;
	cout<<setiosflags(ios::fixed)<<setprecision(1)<<5.0*(f-32)/9<<endl; 
	return 0;
}