#include <iostream>

using namespace std;

void dispB(int b)
{
	if(b>0)
		cout<<b;
	else
		cout<<'('<<b<<')';
}

int main()
{
	int a,b,A,B,C,D;
    cin>>a>>b;
    A=a+b;
    B=a*b;
    C=a/b;
    D=a%b; 
    
    cout<<a<<"+"; dispB(b); cout<<"="<<A<<endl;
    cout<<a<<"*"; dispB(b); cout<<"="<<B<<endl;
    cout<<a<<"/"; dispB(b); cout<<"="<<C<<endl;
    cout<<a<<"%"; dispB(b); cout<<"="<<D<<endl;
    return 0;
}
