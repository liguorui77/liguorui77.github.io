#include <iostream>
using namespace std;

main ()
{
	long a, b;
	int r;
	int m, n;
	cin>>a>>b; 

	if (a > b)
	{
		r = a;
		a = b;
		b = r;
	}

	m = a; n = b;
	while (m)
	{
		r = n % m;
		n = m;
		m = r;
	}
	cout<<n<<b/n*a<<endl;
}