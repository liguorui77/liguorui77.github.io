#include <iostream>
using namespace std;

int main()
{
	int N;
	cin>>N;
	
	for(int i=100;i <= N;i++)
	{
		int gt = i % 10;
		int st = i / 10 % 10;
		int bt = i / 100;
		if(gt*gt*gt + st*st*st + bt*bt*bt == i)
		{
			cout<<i<<endl; 
		}
	}
	return 0;
}