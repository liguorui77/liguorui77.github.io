#include <stdio.h>
#include <string.h>

int main() {
	char s[50];
	int i,j;
	int flag;
	flag=0;
	scanf("%s",s);
	for (i=0,j=strlen(s)-1;i<=j;i++,j--)
	{
		if(s[i]!=s[j])
		{
			flag=1;
			break;
		}

	}
	if (flag==0)
		printf("Yes");
	else
		printf("No");
	return 0;
}