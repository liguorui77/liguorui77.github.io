#include<stdio.h>

char* insert(char *s,char c,char *t) {
	int flag=1;
	while (*s) {
		if (*s>=c) {
			if (flag==1) {
				*t++=c;
				flag=0;
			}
			*t++=*s++;
		}
		else
			*t++=*s++;	
	}
	if (flag==1)
		*t++=c;
	*t='\0';
	return 0;
}

int main() {
	char *s,*t,str[40],str1[50];
	char c,temp;
	s=str;
	scanf("%s",s);
	t=str1;
	scanf("%c",&temp);
	scanf("%c",&c);
	insert(s,c,t);
	printf("%s",t);
	return 0;
}
