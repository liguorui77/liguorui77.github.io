#include <stdio.h>
#include <string.h>
void str_bin(char s1[], char s2[],char s[]) {
	unsigned int i,j,k;
	i=0;
	j=0;
	k=0;
	while (s1[i] && s2[j]) {
		if (s1[i]<s2[j]) 
			s[k++]=s1[i++];
		else
			s[k++]=s2[j++];
	}
	while ( i<strlen(s1) ) 
		s[k++]=s1[i++];
	while ( j<strlen(s2) )
		s[k++]=s2[j++];
	s[k]='\0';
}
int main() {
	char s1[100],s2[100],s[200];
	scanf("%s",s1);
	scanf("%s",s2);
	str_bin(s1,s2,s);
	printf("%s",s);
	return 0;
}