#include<iostream>
using namespace std;
int main(){
	int n;
	cin>>n;
	n=n-1;
	const char *str[]={"Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"};   
	cout<<str[n]<<endl;
	return 0;
}