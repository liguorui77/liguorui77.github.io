#include <iostream>
using namespace std;

int sums(int num)
{
	int sum;
	sum = 0;
	while (num != 0)
	{
		sum += num % 10;
		num /= 10;
	}
	return sum;
}

int main()
{
	int number;
	cin>>number;
	cout<<sums(number);
	return 0;
}
