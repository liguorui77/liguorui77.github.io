#include <iostream>
using namespace std;

int getGe(int number) {
	return number%10;
}
int getBai(int number) {
	return number/10;
}
int main() {
	int number1,number2;
	int a1,a2,b1,b2;
	int result;
	cin>>number1>>number2;
	a1=getGe(number1);
	a2=getBai(number1);
	b1=getGe(number2);
	b2=getBai(number2);
	result=1000*a1+100*b1+10*a2+b2;
	cout<<result;
	return 0;
}
