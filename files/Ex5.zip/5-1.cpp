#include <iostream>
#include <cmath>

using namespace std;

double e(double x)
{
    return exp(x);
}

double sinh(double x)
{
	return (e(x)-e(-x))/2;
} 

int main()
{

	double x, res;
	cin>>x;
	res=sinh(x);
	cout<<res<<endl;
	return 0;
}
