#include <stdio.h>

int main()
{
	int num,n,i,j,k,matr[20][20];

	scanf("%d%d",&num,&n);

	i=0;
	while(i<n)
	{
		for(k=0; k<=i; k++)
			matr[k][i]=num++;
		for(k-=2; k>=0; k--)
			matr[i][k]=num++;
		i++;
	}

	for(i=0;i<n;i++)
	{
		for(j=0;j<n;j++)
			printf("%4d",matr[i][j]);
		printf("\n");
	}

    return 0;
}
