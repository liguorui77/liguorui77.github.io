#include <iostream>
using namespace std;

int main() 
{
	int a;
	cin>>a;
	cout<<"hello , "<<a<<"!"<<endl;
	return 0;
}
