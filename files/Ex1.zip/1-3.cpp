#include <iostream>
#include <iomanip>
using namespace std;

int main() 
{
	int x, y, z;
	int sum;
	double average;
    cin>>x>>y>>z;	
	sum = x + y + z;
	average = (double)sum / 3;
    cout<<sum<<endl;
    cout<<setiosflags(ios::fixed)<<setprecision(2)<<average<<endl;
	return 0;
}

