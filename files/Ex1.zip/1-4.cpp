#include <iostream>
using namespace std;

int main()
{
	float number;
	cin>>number; 
	if (number - (int)number >= 0.5)
		cout<<(int)(number+1);
	else
		cout<<(int)(number);
	return 0;
}
