void Rectangle::setLength(int l)
{
	length=l;
}

void Rectangle::setWidth(int w)
{
	width=w;
}

int Rectangle::getArea()
{
	return (width*length);
}