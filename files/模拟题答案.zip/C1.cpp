#include <iostream>
#include <cmath>
using namespace std; 											

int main()
{	
	int n;
	cin>>n;
	while (n)
	{
		int m[n][n];
		for (int i = 0; i < n; i ++)
		{
			for (int j = 0; j < n; j ++)
			{
				m[i][j] = pow(2, i + j);
			}
		}
		
		for (int i = 0; i < n; i ++)
		{
			for (int j = 0; j < n; j ++)
			{
				cout<<m[i][j]<<" ";
			}
			cout<<endl;
		}	
		cout<<endl;
		cin>>n;
	}	
	return 0;
} 