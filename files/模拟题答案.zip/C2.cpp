#include <iostream>
#include <iomanip>
using namespace std; 											

int main() 
{
  int score;
  int count_A = 0, count_P = 0, count_F = 0;
  while (1) {
  	cin>>score;
  	if(score<0)
  	break;
    if (score >= 90 && score <= 100) {
      count_A++;
    } else if (score >= 60 && score <= 89) {
      count_P++;
    } else if (score >= 0 && score <= 59) {
      count_F++;
    }
  }
  cout<<"A�ȼ�"<<count_A<<"��"<<endl;
  cout<<"P�ȼ�"<<count_P<<"��"<<endl;
  cout<<"F�ȼ�"<<count_F<<"��"<<endl;
  
  return 0;
}