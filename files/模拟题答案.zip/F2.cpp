double fun( int m )
{
	double sum=0;
	for(int i=0;i<=m;i++)
	{
		sum=sum+1.0/(i+2);
	}
	return sum;
}
