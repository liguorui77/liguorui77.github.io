#include <iostream>
#include <iomanip>
using namespace std; 											
int main()
{
	int x,y;
	cin>>x;
	if (x<0)
       y=x-3;              
	else if (x>=-0 &&x<=20)
   		y=6*x+6;
	else
    	y=x*x+6;
	cout<<"f="<<y<<endl;
} 