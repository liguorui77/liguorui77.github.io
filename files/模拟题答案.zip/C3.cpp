#include <iostream>
#include <iomanip>
using namespace std; 											
int main()
{
	int n, i, j, k, max, flag, a[6][6];
	max = flag = 0;
	cin>>n;
	for(i=0; i<n; i++){
		for(j=0; j<n; j++){
			cin>>a[i][j];
		}
	}
	for(i=0; i<n; i++){
		flag = 0;
		for(j=0; j<n; j++){
			if(a[i][j]>=a[i][max]){
				max = j;
			}
		}
		for(k=0; k<n; k++){
			if(a[i][max]>a[k][max]){
				flag = 1;
				break;
			}
		}
		if(!flag){
			cout<<i<<" "<<max;
			break;
		}
	}
	if(flag){
		cout<<"NONE";
	}
	return 0;
}